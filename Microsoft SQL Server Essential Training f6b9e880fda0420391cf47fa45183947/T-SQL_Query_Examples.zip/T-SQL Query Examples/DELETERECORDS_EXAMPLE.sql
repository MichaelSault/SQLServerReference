SELECT * 
FROM [Stark Industries].dbo.Customers;

DELETE FROM Customers
WHERE CustomerID = 1000;

SELECT * FROM Orders;