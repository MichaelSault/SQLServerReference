INSERT INTO ProductCategories (CategoryName, CategoryAbbreviation)
	VALUES ('Blueprints', 'BP'),
		('Drone Kits', 'DK'),
		('Drones', 'DS'),
		('eBooks', 'EB'),
		('Robot Kits', 'RK'),
		('Robots', 'RS'),
		('Training Videos', 'TV')
;