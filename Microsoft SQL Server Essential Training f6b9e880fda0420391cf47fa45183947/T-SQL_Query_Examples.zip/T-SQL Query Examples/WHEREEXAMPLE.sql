SELECT * 
FROM [Stark Industries].dbo.Customers
WHERE Province = 'CA' OR Province = 'NY'
;