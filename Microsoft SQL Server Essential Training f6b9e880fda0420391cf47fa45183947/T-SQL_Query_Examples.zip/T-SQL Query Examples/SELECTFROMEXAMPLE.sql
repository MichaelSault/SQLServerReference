SELECT * FROM [Stark Industries].dbo.Customers;

SELECT [First Name], [Last Name]
FROM [Stark Industries].dbo.Customers;